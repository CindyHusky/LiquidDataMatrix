"""
Liquid Data Matrix
------------------
A NumPy-based feedforward neural network that learns to solve
multiple basic math operations and visualizes both its
"learning space" and loss curve.
"""

import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from scipy.ndimage import gaussian_filter


# -----------------------------
# Utility Functions
# -----------------------------
def softmax(x):
    exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
    return exp_x / np.sum(exp_x, axis=1, keepdims=True)


def cross_entropy_loss(predictions, targets):
    epsilon = 1e-12
    predictions = np.clip(predictions, epsilon, 1. - epsilon)
    return -np.sum(targets * np.log(predictions)) / predictions.shape[0]


def create_one_hot_encoding(result, max_value):
    result = max(1, min(result, max_value))
    one_hot = np.zeros(max_value)
    one_hot[result - 1] = 1
    return one_hot


# -----------------------------
# Liquid Data Matrix Core
# -----------------------------
class LiquidDataMatrix:
    def __init__(self, input_size, hidden_size, output_size,
                 colormap="viridis", learning_rate=1e-4,
                 max_grad_value=1.0, blur_sigma=1.0):

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.colormap = colormap
        self.learning_rate = learning_rate
        self.max_grad_value = max_grad_value
        self.blur_sigma = blur_sigma

        self.W1 = np.random.randn(input_size, hidden_size) * 0.01
        self.b1 = np.zeros((1, hidden_size))
        self.W2 = np.random.randn(hidden_size, output_size) * 0.01
        self.b2 = np.zeros((1, output_size))

        self.learning_space = np.zeros((hidden_size * 2, output_size * 2))
        self._kron_tile = np.ones((2, 2))

        # Store loss history
        self.loss_history = []

    def forward(self, X):
        self.a1 = np.dot(X, self.W1) + self.b1
        self.z1 = np.tanh(self.a1)
        self.a2 = np.dot(self.z1, self.W2) + self.b2
        self.output = softmax(self.a2)
        return self.output

    def backward_batch(self, X, y, output):
        batch_size = X.shape[0]
        dloss_da2 = (output - y) / batch_size
        dloss_dW2 = np.dot(self.z1.T, dloss_da2)
        dloss_db2 = np.sum(dloss_da2, axis=0, keepdims=True)

        dloss_dz1 = np.dot(dloss_da2, self.W2.T)
        dloss_da1 = dloss_dz1 * (1 - self.z1 ** 2)
        dloss_dW1 = np.dot(X.T, dloss_da1)
        dloss_db1 = np.sum(dloss_da1, axis=0, keepdims=True)

        for grad in (dloss_dW1, dloss_db1, dloss_dW2, dloss_db2):
            np.clip(grad, -self.max_grad_value, self.max_grad_value, out=grad)

        self.W1 -= self.learning_rate * dloss_dW1
        self.b1 -= self.learning_rate * dloss_db1
        self.W2 -= self.learning_rate * dloss_dW2
        self.b2 -= self.learning_rate * dloss_db2

        self.update_learning_space_batch(dloss_da2)

    def update_learning_space_batch(self, dloss_da2):
        perceptron_activity_avg = np.mean(self.z1, axis=0, keepdims=True)
        error_significance_avg = np.mean(np.abs(dloss_da2), axis=0, keepdims=True)
        adjustment = np.dot(perceptron_activity_avg.T, error_significance_avg) * 0.01
        doubled_adjustment = np.kron(adjustment, self._kron_tile)
        self.learning_space += doubled_adjustment
        self.learning_space = gaussian_filter(self.learning_space, sigma=self.blur_sigma)

    def visualize_learning_space(self):
        plt.imshow(self.learning_space, cmap=self.colormap, interpolation='nearest')
        plt.title("Liquid Data Matrix Learning Space")
        plt.colorbar()
        plt.show()

    def plot_loss(self):
        plt.plot(self.loss_history)
        plt.xlabel("Epochs")
        plt.ylabel("Loss")
        plt.title("Training Loss Over Time")
        plt.grid(True)
        plt.show()

    def train(self, samples, epochs=50000, batch_size=32, vis_interval=1000):
        num_samples = len(samples)
        for epoch in tqdm(range(epochs), desc="Training Epochs"):
            batch_indices = np.random.choice(num_samples, batch_size, replace=False)
            X_batch = np.array([samples[i][0] for i in batch_indices])
            y_batch = np.array([samples[i][2] for i in batch_indices])

            predictions = self.forward(X_batch)
            loss = cross_entropy_loss(predictions, y_batch)
            self.loss_history.append(loss)
            self.backward_batch(X_batch, y_batch, predictions)

            if epoch % vis_interval == 0:
                print(f"\nEpoch {epoch}/{epochs} | Loss: {loss:.6f}")
                print("Example Problem:", samples[batch_indices[0]][1])
                self.visualize_learning_space()

        # Show loss graph after training
        self.plot_loss()


# -----------------------------
# Dataset Generator
# -----------------------------
def generate_math_dataset(num_samples_per_task=1000, min_val=1, max_val=10, output_size=150):
    samples = []
    rng = np.random.default_rng()

    for _ in range(num_samples_per_task):
        a, b = rng.integers(min_val, max_val+1, size=2)
        samples.append(([a, b, 0], f"{a} + {b}", create_one_hot_encoding(a+b, output_size)))

    for _ in range(num_samples_per_task):
        a = rng.integers(min_val, max_val+1)
        b = rng.integers(min_val, a+1)
        samples.append(([a, b, 0], f"{a} - {b}", create_one_hot_encoding(a-b+1, output_size)))

    for _ in range(num_samples_per_task):
        a, b = rng.integers(min_val, max_val+1, size=2)
        samples.append(([a, b, 0], f"{a} × {b}", create_one_hot_encoding(a*b, output_size)))

    for _ in range(num_samples_per_task):
        b = rng.integers(min_val, max_val+1)
        a = b * rng.integers(1, max_val+1)
        samples.append(([a, b, 0], f"{a} ÷ {b}", create_one_hot_encoding(a//b, output_size)))

    for _ in range(num_samples_per_task):
        a = rng.integers(min_val, max_val+1)
        x = rng.integers(min_val, max_val+1)
        b = rng.integers(-max_val, max_val+1)
        c = a * x + b
        samples.append(([a, b, c], f"Solve {a}x + {b} = {c}", create_one_hot_encoding(x, output_size)))

    for _ in range(num_samples_per_task):
        a = rng.integers(1, 6)
        b = rng.integers(0, 4)
        samples.append(([a, b, 0], f"{a}^{b}", create_one_hot_encoding(a**b, output_size)))

    for _ in range(num_samples_per_task):
        a, b = rng.integers(min_val, max_val+1, size=2)
        c = rng.integers(min_val, 6)
        samples.append(([a, b, c], f"({a} + {b}) × {c}", create_one_hot_encoding((a+b)*c, output_size)))

    return samples


# -----------------------------
# Main
# -----------------------------
if __name__ == "__main__":
    ldm = LiquidDataMatrix(input_size=3, hidden_size=32, output_size=150)
    dataset = generate_math_dataset(num_samples_per_task=1000, min_val=1, max_val=10, output_size=150)
    ldm.train(dataset, epochs=40000, batch_size=1, vis_interval=10000)
