#!/usr/bin/env python3
"""
LDM_Project_POC_fixed.py

Merged, cleaned, and double-checked version of the LDM prototype.
- Single module (no duplicate docstrings)
- Device-aware (CPU / CUDA) model and memory bank
- Fixed minor shape/reshape issues and ensured prototypes live on model device
- Basic runtime debug prints and safe checkpoint save/load
- Keeps matplotlib plotting only in demo mode to avoid realtime GUI conflicts

Requirements:
    Python 3.8+
    numpy, opencv-python, matplotlib (optional), torch

Quick start examples (same as original):
    python LDM_Project_POC_fixed.py --realtime
    python LDM_Project_POC_fixed.py --demo
"""

import argparse
import os
import math

import numpy as np
import cv2
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.optim as optim


# ------------------------- Helpers -------------------------

def choose_device(force_cuda: bool = False) -> torch.device:
    """
    If force_cuda is True, require CUDA and raise an error if not available.
    Otherwise return CPU device.
    """
    if force_cuda:
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA was forced but torch.cuda.is_available() is False. Check drivers/PyTorch build.")
        torch.backends.cudnn.benchmark = True
        return torch.device("cuda")
    return torch.device("cpu")


# ------------------------- Pixel Vector Mapper -------------------------
class PixelVector:
    def __init__(self, vector_size: int, img_shape: tuple | None = None):
        self.vector_size = int(vector_size)
        if img_shape is None:
            img_shape = None
            for pref in (128, 64, 32):
                if self.vector_size % pref == 0:
                    w = pref
                    h = self.vector_size // w
                    img_shape = (h, w)
                    break
            if img_shape is None:
                s = int(math.sqrt(self.vector_size))
                h = s
                w = (self.vector_size + s - 1) // s
                img_shape = (h, w)
        self.img_shape = img_shape
        assert self.img_shape[0] * self.img_shape[1] == self.vector_size, "img shape must match vector size"

    def to_image(self, vec: np.ndarray) -> np.ndarray:
        return vec.reshape(self.img_shape)


# ------------------------- Novelty Detector & Memory Bank -------------------------
class MemoryBank:
    def __init__(self, capacity: int = 8192, prototype_dim: int = 8192, novelty_threshold: float = 0.72,
                 device: torch.device = torch.device('cpu')):
        self.capacity = int(capacity)
        self.prototype_dim = int(prototype_dim)
        self.novelty_threshold = float(novelty_threshold)
        self.device = device
        # prototypes stored on the configured device
        self.prototypes = torch.empty((0, self.prototype_dim), device=self.device, dtype=torch.float32)

    def is_novel(self, vec: torch.Tensor) -> tuple[bool, int | None]:
        """
        vec: 1D torch tensor (prototype_dim) on any device — we'll move to memory device
        Returns (novel: bool, best_idx: int|None)
        """
        v = vec.to(self.device).reshape(-1)
        if self.prototypes.shape[0] == 0:
            return True, None
        # normalize
        v_norm = v / (v.norm() + 1e-8)
        P = self.prototypes / (self.prototypes.norm(dim=1, keepdim=True) + 1e-8)
        sims = P.matmul(v_norm)
        best, idx = torch.max(sims, dim=0)
        novel = (best.item() < self.novelty_threshold)
        return novel, int(idx.item())

    def store(self, vec: torch.Tensor) -> None:
        v = vec.to(self.device).reshape(1, -1).float()
        if self.prototypes.shape[0] < self.capacity:
            self.prototypes = torch.cat([self.prototypes, v], dim=0)
        else:
            i = torch.randint(0, self.capacity, (1,), device=self.device).item()
            self.prototypes[i] = v


# ------------------------- PyTorch LDM Model -------------------------
class LDMModel(nn.Module):
    def __init__(self, input_dim: int, encoder_hidden: int, pixel_vector_size: int, infer_hidden: int):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(int(input_dim), int(encoder_hidden)),
            nn.LeakyReLU(0.1)
        )
        self.to_pixel = nn.Sequential(
            nn.Linear(int(encoder_hidden), int(pixel_vector_size)),
            nn.Sigmoid()
        )
        self.infer1 = nn.Sequential(
            nn.Linear(int(pixel_vector_size), int(infer_hidden)),
            nn.LeakyReLU(0.1)
        )
        self.infer2 = nn.Sequential(
            nn.Linear(int(infer_hidden), int(input_dim)),
            nn.Sigmoid()
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight, a=0.1)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def encode(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        h = self.encoder(x)
        p = self.to_pixel(h)
        return h, p

    def infer(self, p: torch.Tensor) -> torch.Tensor:
        h = self.infer1(p)
        out = self.infer2(h)
        return out

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        h, p = self.encode(x)
        out = self.infer(p)
        return out, p


# ------------------------- LDM System (wrapper) -------------------------
class LDMSystem:
    def __init__(self,
                 scale: int = 16,
                 base_input_dim: int = 64,
                 base_encoder_hidden: int = 128,
                 base_pixel_vector: int = 256,
                 base_infer_hidden: int = 128,
                 lr: float = 5e-4,
                 novelty_lr_factor: float = 8.0,
                 novelty_threshold: float = 0.72,
                 device: torch.device = torch.device('cpu')):
        # sizes (allow large scaling)
        self.scale = int(scale)
        self.input_dim = int(base_input_dim) * self.scale
        self.encoder_hidden = int(base_encoder_hidden) * self.scale
        self.pixel_vector_size = int(base_pixel_vector) * self.scale
        self.infer_hidden = int(base_infer_hidden) * self.scale

        self.device = device

        # instantiate model on correct device
        self.model = LDMModel(self.input_dim, self.encoder_hidden, self.pixel_vector_size, self.infer_hidden).to(self.device)

        # optimizers (all parameters on model device)
        self.lr = float(lr)
        self.novelty_lr_factor = float(novelty_lr_factor)
        self.main_optimizer = optim.Adam(self.model.parameters(), lr=self.lr)
        enc_params = list(self.model.encoder.parameters()) + list(self.model.to_pixel.parameters())
        self.novelty_optimizer = optim.Adam(enc_params, lr=self.lr * self.novelty_lr_factor)

        # memory bank — ensure it uses the same device as model (so similarity ops are fast)
        self.memory = MemoryBank(capacity=8192, prototype_dim=self.pixel_vector_size,
                                 novelty_threshold=novelty_threshold, device=self.device)

        # pixel display mapper (CPU-only structure)
        self.pixel_mapper = PixelVector(self.pixel_vector_size)

        # input reshape heuristics (for recon display)
        if self.input_dim % 128 == 0:
            self.src_hw = (self.input_dim // 128, 128)
        elif self.input_dim % 64 == 0:
            self.src_hw = (self.input_dim // 64, 64)
        else:
            s = int(math.sqrt(self.input_dim))
            self.src_hw = (s, (self.input_dim + s - 1) // s)

        self.loss_fn = nn.MSELoss()

        # running input normalization (keep on CPU as numpy arrays)
        self.running_mean = 0.0
        self.running_var = 1.0
        self.running_count = 0

        # debug info
        print(f"[LDMSystem] model device: {next(self.model.parameters()).device}")
        print(f"[LDMSystem] input_dim={self.input_dim}, pixel_vector_size={self.pixel_vector_size}, src_hw={self.src_hw}")

    def update_running_stats(self, x_np: np.ndarray) -> None:
        x = x_np.reshape(-1)
        self.running_count += 1
        if self.running_count == 1:
            self.running_mean = x.copy()
            self.running_var = np.zeros_like(x)
        else:
            old_mean = self.running_mean
            new_mean = old_mean + (x - old_mean) / self.running_count
            # numerically-stable running variance update
            self.running_var = ((self.running_count - 2) / (self.running_count - 1)) * self.running_var + (x - old_mean) * (x - new_mean)
            self.running_mean = new_mean

    def normalize_input(self, x_np: np.ndarray) -> np.ndarray:
        if self.running_count < 2:
            # not enough stats yet — return as column vector
            return x_np.reshape(-1, 1)
        std = np.sqrt(self.running_var / (self.running_count - 1) + 1e-6)
        normed = (x_np.reshape(-1) - self.running_mean) / std
        # min/max to [0,1] for stable training/pixel display
        normed = (normed - normed.min()) / (normed.max() - normed.min() + 1e-9)
        return normed.reshape(-1, 1)

    def train_step(self, x_np: np.ndarray) -> tuple[float, bool]:
        # update running stats for stable learning
        self.update_running_stats(x_np)
        x_norm = self.normalize_input(x_np)

        # move to model device
        x = torch.tensor(x_norm.T, dtype=torch.float32, device=self.device)  # shape (1, input_dim)
        self.main_optimizer.zero_grad()
        out, p = self.model(x)
        loss = self.loss_fn(out, x)
        loss.backward()
        self.main_optimizer.step()

        # operate similarity checks on model device (avoid unnecessary cpu/gpu moving)
        p_flat = p.detach().reshape(-1)  # still on self.device
        novel, idx = self.memory.is_novel(p_flat)
        if novel:
            # novelty-specific small-step update to encoder/to_pixel to consolidate new pattern
            self.novelty_optimizer.zero_grad()
            out2, p2 = self.model(x)
            loss2 = self.loss_fn(out2, x)
            loss2.backward()
            self.novelty_optimizer.step()
            # store the prototype on memory device (memory uses same device)
            self.memory.store(p2.detach().reshape(-1))

        return float(loss.item()), novel

    def adapt_step(self, x_np: np.ndarray, adapt_lr: float = 1e-4) -> float:
        x_norm = self.normalize_input(x_np)
        x = torch.tensor(x_norm.T, dtype=torch.float32, device=self.device)
        enc_params = list(self.model.encoder.parameters()) + list(self.model.to_pixel.parameters())
        adapt_opt = optim.Adam(enc_params, lr=adapt_lr)
        adapt_opt.zero_grad()
        out, p = self.model(x)
        loss = self.loss_fn(out, x)
        loss.backward()
        adapt_opt.step()
        return float(loss.item())

    def infer_only(self, x_np: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        x_norm = self.normalize_input(x_np)
        x = torch.tensor(x_norm.T, dtype=torch.float32, device=self.device)
        with torch.no_grad():
            out, p = self.model(x)
        out_np = out.detach().cpu().numpy().reshape(-1)
        p_np = p.detach().cpu().numpy().reshape(-1)
        return out_np, p_np

    def pixel_to_display(self, p_vec: np.ndarray, upsample: int = 512) -> np.ndarray:
        vec = p_vec.reshape(-1)
        L = vec.size
        if L % 3 == 0:
            c = L // 3
            # split into channels
            r = vec[:c].reshape(self.pixel_mapper.img_shape)
            g = vec[c:2*c].reshape(self.pixel_mapper.img_shape)
            b = vec[2*c:3*c].reshape(self.pixel_mapper.img_shape)
            rgb = np.stack([r, g, b], axis=2)
            img = np.clip(rgb, 0, 1)
            img_u = cv2.resize((img * 255).astype(np.uint8), (upsample, upsample), interpolation=cv2.INTER_NEAREST)
            return cv2.cvtColor(img_u, cv2.COLOR_RGB2BGR)
        else:
            img = vec.reshape(self.pixel_mapper.img_shape)
            img = np.clip(img, 0, 1)
            img_u = cv2.resize((img * 255).astype(np.uint8), (upsample, upsample), interpolation=cv2.INTER_NEAREST)
            return cv2.cvtColor(img_u, cv2.COLOR_GRAY2BGR)

    def recon_to_display(self, recon_vec: np.ndarray, upsample: int = 512) -> np.ndarray:
        img = recon_vec.reshape(self.src_hw)
        img = np.clip(img, 0, 1)
        img_u = cv2.resize((img * 255).astype(np.uint8), (upsample, upsample), interpolation=cv2.INTER_LINEAR)
        return cv2.cvtColor(img_u, cv2.COLOR_GRAY2BGR)

    def save_checkpoint(self, path: str = "ldm_pytorch_checkpoint.pt") -> None:
        state = {
            'model': self.model.state_dict(),
            'optimizer': self.main_optimizer.state_dict(),
            # move prototypes to cpu before saving
            'memory': self.memory.prototypes.detach().cpu().numpy(),
            'running_mean': self.running_mean,
            'running_var': self.running_var,
            'running_count': self.running_count
        }
        torch.save(state, path)
        print(f"[LDMSystem] checkpoint saved to {path}")

    def load_checkpoint(self, path: str = "ldm_pytorch_checkpoint.pt") -> bool:
        if not os.path.exists(path):
            return False
        state = torch.load(path, map_location=self.device)
        self.model.load_state_dict(state['model'])
        try:
            self.main_optimizer.load_state_dict(state['optimizer'])
        except Exception:
            pass
        mem = state.get('memory', np.zeros((0, self.memory.prototype_dim)))
        # ensure prototypes land on memory device
        self.memory.prototypes = torch.tensor(mem, dtype=torch.float32, device=self.memory.device)
        self.running_mean = state.get('running_mean', self.running_mean)
        self.running_var = state.get('running_var', self.running_var)
        self.running_count = state.get('running_count', self.running_count)
        print(f"[LDMSystem] checkpoint loaded from {path}")
        return True


# ------------------------- Utils: frame -> input vector -------------------------

def frame_to_input_vector(frame_gray: np.ndarray, input_dim: int, src_hw: tuple[int, int]) -> np.ndarray:
    small = cv2.resize(frame_gray, (src_hw[1], src_hw[0]), interpolation=cv2.INTER_AREA)
    vec = (small.astype(np.float32) / 255.0).reshape(-1)
    if vec.shape[0] != input_dim:
        if vec.shape[0] > input_dim:
            vec = vec[:input_dim]
        else:
            pad = np.zeros(input_dim - vec.shape[0], dtype=vec.dtype)
            vec = np.concatenate([vec, pad])
    return vec.reshape(-1, 1)


# ------------------------- Demo (synthetic) -------------------------

def synthetic_input_patterns(n_patterns: int = 32, input_dim: int = 4096, noise: float = 0.04):
    bases = []
    rng = np.random.RandomState(0)
    for i in range(n_patterns):
        v = np.zeros(input_dim)
        idx = rng.choice(range(input_dim), size=max(8, input_dim // 16), replace=False)
        v[idx] = 1.0
        bases.append(v)
    i = 0
    while True:
        p = bases[i % len(bases)] + rng.randn(input_dim) * noise
        p = np.clip(p, 0, 1)
        yield p.reshape(-1, 1)
        i += 1


def run_demo(steps: int = 400, show_every: int = 100, scale: int = 16, use_cuda: bool = False):
    device = choose_device(force_cuda=use_cuda)
    sys = LDMSystem(scale=scale, device=device)
    gen = synthetic_input_patterns(n_patterns=40, input_dim=sys.input_dim, noise=0.05)

    losses = []
    nov_counts = 0
    for t in range(steps):
        x = next(gen)
        loss, novel = sys.train_step(x)
        losses.append(loss)
        if novel:
            nov_counts += 1
        if (t + 1) % show_every == 0:
            print(f"step {t+1}/{steps}  loss={np.mean(losses[-show_every:]):.5f}  novel_count={nov_counts}")
            out_np, p_np = sys.infer_only(x)
            plt.figure(figsize=(6, 6))
            try:
                plt.imshow(p_np.reshape(sys.pixel_mapper.img_shape), cmap='gray', vmin=0, vmax=1)
                plt.title(f"step {t+1} pixel (novel={novel})")
                plt.axis('off')
                plt.show()
            except Exception as e:
                print("Plot failed:", e)

    plt.figure()
    plt.plot(losses)
    plt.title('Training loss')
    plt.xlabel('step')
    plt.ylabel('mse')
    plt.show()
    sys.save_checkpoint()
    print('Demo complete.')


# ------------------------- Real-time OBS/webcam mode (PyTorch) -------------------------

def run_realtime(device: int = 0, train: bool = False, scale: int = 16, use_cuda: bool = False, cam_backend: str | None = None, adapt: bool = True):
    device_t = choose_device(force_cuda=use_cuda)

    # robust VideoCapture
    cap = None
    try:
        if cam_backend == 'dshow' and hasattr(cv2, 'CAP_DSHOW'):
            cap = cv2.VideoCapture(device, cv2.CAP_DSHOW)
        else:
            cap = cv2.VideoCapture(device)
            if not cap.isOpened() and hasattr(cv2, 'CAP_DSHOW'):
                cap.release()
                cap = cv2.VideoCapture(device, cv2.CAP_DSHOW)
    except Exception:
        cap = cv2.VideoCapture(device)

    if not cap.isOpened():
        raise RuntimeError(f"Could not open camera device {device}. Try a different index or start OBS Virtual Camera.")

    sys = LDMSystem(scale=scale, device=device_t)

    # safety debug prints
    print(f"Realtime mode started. camera_device={device} | forced_cuda={use_cuda} | model_device={next(sys.model.parameters()).device}")
    print("Press 'q' to quit. Press 's' to save a checkpoint.")

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print('Frame read failed; exiting')
                break
            frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            inp = frame_to_input_vector(frame_gray, input_dim=sys.input_dim, src_hw=sys.src_hw)

            if train:
                loss, novel = sys.train_step(inp)
            else:
                if adapt:
                    loss = sys.adapt_step(inp, adapt_lr=2e-4)
                    novel = False
                else:
                    out_np, p_np = sys.infer_only(inp)
                    loss, novel = None, False

            out_np, p_np = sys.infer_only(inp)

            # displays
            orig_display = cv2.resize(frame, (480, 360))
            pixel_display = sys.pixel_to_display(p_np, upsample=360)
            recon_display = sys.recon_to_display(out_np, upsample=360)

            combined = np.hstack([orig_display, pixel_display, recon_display])
            cv2.imshow('LDM - original | pixel | reconstruction', combined)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            if key == ord('s'):
                sys.save_checkpoint()
    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--demo', action='store_true', help='Run synthetic demo')
    parser.add_argument('--realtime', action='store_true', help='Run realtime camera mode')
    parser.add_argument('--device', type=int, default=0, help='Camera device index for OpenCV (OBS virtual camera likely not 0)')
    parser.add_argument('--train', action='store_true', help='Enable online training in realtime mode')
    parser.add_argument('--cuda', action='store_true', help='Force CUDA usage (will raise if CUDA unavailable)')
    parser.add_argument('--scale', type=int, default=16, help='Scale factor to multiply base sizes (default 16)')
    parser.add_argument('--backend', choices=['dshow', 'default'], default='default', help='Camera backend for OpenCV on Windows')
    parser.add_argument('--no-adapt', action='store_true', help='Disable tiny per-frame adaptation (enabled by default)')
    args = parser.parse_args()

    try:
        if args.demo:
            run_demo(steps=400, show_every=100, scale=args.scale, use_cuda=args.cuda)
        else:
            if not args.realtime:
                print('No mode selected. Defaulting to realtime mode. Use --demo for offline demo.')
            adapt_flag = not args.no_adapt
            run_realtime(device=args.device, train=args.train, scale=args.scale, use_cuda=args.cuda, cam_backend=args.backend, adapt=adapt_flag)
    except RuntimeError as e:
        print('Realtime startup error:', e)
        print('Make sure CUDA is available if you passed --cuda, and that your camera device index is correct.')
        try:
            input('Press Enter to exit...')
        except Exception:
            pass
    except Exception as e:
        print('Unhandled exception:', repr(e))
        try:
            input('Press Enter to exit...')
        except Exception:
            pass
