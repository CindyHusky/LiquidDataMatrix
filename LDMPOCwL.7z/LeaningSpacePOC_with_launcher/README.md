# LeaningSpacePOC

Lightweight LDM-style proof-of-concept for transforming webcam frames into a compact pixel representation and reconstructing them in real time.

## Overview

This repository demonstrates a small, didactic implementation of a "liquid data matrix" concept: encoding arbitrary input into a compact pixel-like vector, then using a small reader network to infer/reconstruct inputs. The code is intended as a research prototype and educational example, not production software.

## Highlights

- Real-time webcam / OBS virtual camera input (OpenCV)
- PyTorch model with optional CUDA acceleration
- Per-frame lightweight adaptation and a simple novelty memory bank
- Simple, readable single-file implementation for experimentation

## Quickstart

```bash
# clone your repo (or run in-place)
git clone https://github.com/CindyHusky/LeaningSpacePOC.git
cd LeaningSpacePOC

# Option A: copy files from this patch
unzip /path/to/LeaningSpacePOC_patch.zip -d tmp_patch && cp -r tmp_patch/* . && rm -rf tmp_patch

# Install requirements (prefer a venv)
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Run demo:
python LDM_Project_POC_fixed.py --demo

# Run realtime (default camera):
python LDM_Project_POC_fixed.py --realtime
```

## License

This project is licensed under the GNU Affero General Public License v3. See LICENSE.

## Contact

Cindy Husky - repository owner
