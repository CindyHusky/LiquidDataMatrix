#!/usr/bin/env python3
import os
import shlex
import subprocess
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Windows-specific flag to spawn a new console for the child process
CREATE_NEW_CONSOLE = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)

# Default script path: prefer local repo script if present
_default_local = os.path.abspath("LDM_Project_POC_fixed.py")
if os.path.exists(_default_local):
    DEFAULT_SCRIPT = _default_local
else:
    DEFAULT_SCRIPT = os.path.expanduser(r"%USERPROFILE%\Downloads\LeaningSpacePOC_with_launcher\CUDAisy beta 1.1.py")
    DEFAULT_SCRIPT = os.path.expandvars(DEFAULT_SCRIPT)

class LauncherApp:
    def __init__(self, root):
        self.root = root
        root.title("LDM Launcher")
        root.geometry("640x420")

        frm = ttk.Frame(root, padding=10)
        frm.pack(fill="both", expand=True)

        # Script selector
        row = 0
        ttk.Label(frm, text="LDM script:").grid(column=0, row=row, sticky="w")
        self.script_var = tk.StringVar(value=DEFAULT_SCRIPT)
        self.script_entry = ttk.Entry(frm, textvariable=self.script_var, width=70)
        self.script_entry.grid(column=0, row=row+1, columnspan=3, sticky="w")
        ttk.Button(frm, text="Browse", command=self.browse).grid(column=3, row=row+1, sticky="e")

        # Options
        row += 2
        ttk.Label(frm, text="Device:").grid(column=0, row=row, sticky="w")
        self.device = tk.StringVar(value="0")
        ttk.Entry(frm, textvariable=self.device, width=6).grid(column=0, row=row, sticky="e", padx=(60,0))

        ttk.Label(frm, text="Scale:").grid(column=1, row=row, sticky="w")
        # match script default scale for usability
        self.scale = tk.StringVar(value="16")
        ttk.Entry(frm, textvariable=self.scale, width=8).grid(column=1, row=row, sticky="e", padx=(40,0))

        ttk.Label(frm, text="Backend:").grid(column=2, row=row, sticky="w")
        self.backend = tk.StringVar(value="default")
        ttk.Combobox(frm, textvariable=self.backend, values=["default","dshow"], width=10).grid(column=2, row=row, sticky="e")

        row += 1
        # Flags
        self.cuda_var = tk.BooleanVar(value=True)
        self.train_var = tk.BooleanVar(value=False)
        self.demo_var = tk.BooleanVar(value=False)
        self.no_adapt_var = tk.BooleanVar(value=False)

        ttk.Checkbutton(frm, text="Force CUDA (--cuda)", variable=self.cuda_var).grid(column=0, row=row, sticky="w")
        ttk.Checkbutton(frm, text="Online train (--train)", variable=self.train_var).grid(column=1, row=row, sticky="w")
        ttk.Checkbutton(frm, text="Run demo (synthetic) (--demo)", variable=self.demo_var).grid(column=2, row=row, sticky="w")
        ttk.Checkbutton(frm, text="Disable per-frame adapt (--no-adapt)", variable=self.no_adapt_var).grid(column=0, row=row+1, columnspan=3, sticky="w")

        # Buttons
        row += 3
        btn_frame = ttk.Frame(frm)
        btn_frame.grid(column=0, row=row, columnspan=4, pady=10)
        self.start_btn = ttk.Button(btn_frame, text="Start", command=self.start)
        self.start_btn.pack(side="left", padx=6)
        self.stop_btn = ttk.Button(btn_frame, text="Stop", command=self.stop, state="disabled")
        self.stop_btn.pack(side="left", padx=6)
        ttk.Button(btn_frame, text="Open folder", command=self.open_folder).pack(side="left", padx=6)
        ttk.Button(btn_frame, text="Copy command", command=self.copy_cmd).pack(side="left", padx=6)

        # Status / log
        row += 1
        ttk.Label(frm, text="Status / logs:").grid(column=0, row=row, sticky="w")
        self.log = tk.Text(frm, height=10, wrap="none")
        self.log.grid(column=0, row=row+1, columnspan=4, sticky="nsew")
        frm.rowconfigure(row+1, weight=1)

        self.proc = None
        self._lock = threading.Lock()

    def browse(self):
        f = filedialog.askopenfilename(title="Select LDM script", filetypes=[("Python files","*.py"),("All files","*.*")])
        if f:
            self.script_var.set(f)

    def log_print(self, *parts):
        self.log.insert("end", " ".join(str(p) for p in parts) + "\n")
        self.log.see("end")

    def build_cmd(self):
        script = self.script_var.get()
        if not script or not os.path.exists(script):
            raise FileNotFoundError("Script not found: " + script)

        python = os.environ.get("PYTHON", "python")
        args = [python, script]

        if self.demo_var.get():
            args.append("--demo")
        else:
            args.append("--realtime")

        args += ["--device", str(self.device.get())]
        args += ["--scale", str(self.scale.get())]
        args += ["--backend", str(self.backend.get())]

        if self.cuda_var.get():
            args.append("--cuda")
        if self.train_var.get():
            args.append("--train")
        if self.no_adapt_var.get():
            args.append("--no-adapt")

        return args

    def start(self):
        try:
            cmd = self.build_cmd()
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        self.log_print("[LAUNCH] ", " ".join(cmd))
        # run in a new console on Windows so the LDM script's prints are visible
        try:
            with self._lock:
                if os.name == "nt" and CREATE_NEW_CONSOLE:
                    self.proc = subprocess.Popen(cmd, creationflags=CREATE_NEW_CONSOLE)
                else:
                    self.proc = subprocess.Popen(cmd)
        except Exception as e:
            self.log_print("[ERROR] Failed to start process:", e)
            return

        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.monitor_thread = threading.Thread(target=self._monitor_proc, daemon=True)
        self.monitor_thread.start()

    def _monitor_proc(self):
        proc = self.proc
        if proc is None:
            return
        ret = proc.wait()
        self.log_print(f"[PROCESS EXITED] returncode={ret}")
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.proc = None

    def stop(self):
        with self._lock:
            if self.proc and self.proc.poll() is None:
                try:
                    self.proc.terminate()
                    self.log_print("[LAUNCHER] Sent terminate to process.")
                except Exception as e:
                    self.log_print("[LAUNCHER] Failed to terminate:", e)

    def open_folder(self):
        script = os.path.abspath(self.script_var.get())
        folder = os.path.dirname(script)
        if os.path.exists(folder):
            if os.name == "nt":
                os.startfile(folder)
            else:
                subprocess.Popen(["xdg-open", folder])

    def copy_cmd(self):
        try:
            cmd = " ".join(self.build_cmd())
            self.root.clipboard_clear()
            self.root.clipboard_append(cmd)
            self.log_print("[LAUNCHER] Command copied to clipboard.")
        except Exception as e:
            self.log_print("[LAUNCHER] Failed to copy command:", e)

if __name__ == "__main__":
    root = tk.Tk()
    app = LauncherApp(root)
    root.mainloop()
