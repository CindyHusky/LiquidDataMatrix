#!/usr/bin/env bash
python LDM_Project_POC_fixed.py --demo
